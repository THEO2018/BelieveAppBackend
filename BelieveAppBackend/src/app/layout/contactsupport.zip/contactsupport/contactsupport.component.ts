import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactsupport',
  templateUrl: './contactsupport.component.html',
  styleUrls: ['./contactsupport.component.scss']
})
export class ContactsupportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
