import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { NewsRoutingModule as Ng2Charts } from 'ng2-charts';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { NewsRoutingModule } from './news-routing.module';
import { NewsComponent } from './news.component';
import { PageHeaderModule } from '../../shared';
import {DataTableModule} from "angular2-datatable";

@NgModule({
    imports: [CommonModule,DataTableModule,  MatTabsModule,MatButtonModule,MatMenuModule,
        MatToolbarModule,MatIconModule,MatCardModule,NewsRoutingModule, PageHeaderModule,
        FormsModule,
        ReactiveFormsModule],
    declarations: [NewsComponent]
})
export class NewsModule {}
