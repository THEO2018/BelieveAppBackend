import { Component, OnInit,ElementRef, ViewChild,ViewContainerRef } from '@angular/core';
import { AuthServiceService } from '../../auth-service.service';
import { FormBuilder, FormControl,FormGroup,FormArray, Validators  } from '@angular/forms';
import * as $ from 'jquery';
import 'datatables.net';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

declare var jQuery:any;


@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.scss']
})
export class NewsComponent implements OnInit
 {
rForm: FormGroup;
eForm: FormGroup;
res:any;
data:any;
id:any;
mytable:any;
browse: boolean = false;
loaded: boolean = false;
imageSrc: string = '';
imageLoaded: boolean = false;
imageUrl: any;
link_status:any;
links:any;
nameary=[];
arryData:any;
image: boolean = false;
_id:any;
link_status_val: boolean = false;
img: boolean = true;
img_valid: boolean = true;
add_new: boolean = false;
urlPattern = "^(http:\/\/www.|https:\/\/www.|http:\/\/|https:\/\/|www.){1}([0-9A-Za-z].+)";

  constructor(
  private router: Router,
    public authService: AuthServiceService,
    public fb: FormBuilder,
    private toastr: ToastrService,
    private vcr: ViewContainerRef) { 
    this.rForm = this.fb.group({
        'news_url' : [null, Validators.required],
        'name' : [null, Validators.required],
        'description': ['', Validators.required]
        });
    this.eForm = this.fb.group({
        'news_url' : [null, Validators.required],
        'name' : [null, Validators.required],
        'description': ['', Validators.required]
        });
    }


  ngAfterContentChecked(){
          $("#web").on("keypress", function (e) {
          if (e.which === 32 && !this.value.length)
          e.preventDefault();
          });

          $("#name").on("keypress", function (e) {
          if (e.which === 32 && !this.value.length)
          e.preventDefault();
          });
     }
  ngOnInit() {
     this.getlibrary();
         setTimeout(() => {
   this.mytable=$('#example').DataTable({
    "bPaginate": true,
    "bLengthChange": true,
    // "pageLength": 7,
    "bFilter": true,
    "bInfo": false,
    "bAutoWidth": true,
    //"ordering": false
    })
   
    },500);
  this.News();
  }

   showAdd(){
      this.add_new=true;
    }
    cancel(){
       this.add_new=false;
    }
     clearr(){
          this.rForm.reset({
            'news_url': '',
            'name': ''
           });
       }
       clearr1(){
          this.eForm.reset({
            'news_url': '',
            'name': ''
           });
       }
   editModal(id,val,name){
      console.log("edit modalll",val)
      this.id=id;
       this.eForm.get('news_url').setValue(val);
        this.eForm.get('name').setValue(name);
       jQuery("#edit").modal("show");
    }

      RemoveClick(id){
      // alert(id)
      jQuery("#request").modal("show");
      this._id=id;

    }


openModal() {
jQuery('#gallerymodal').modal({backdrop: 'static', keyboard: false});
  jQuery("#gallerymodal").modal("show");
  this.getlibrary();
}




// get media library/////
getlibrary() {
  console.log('manager lsit');
  this.authService.getLibrary().then((result) => {
    console.log(result);
    this.res = result;
    console.log('lasun', this.res);
    if (this.res.status == true) {
      this.arryData = this.res.data;
      console.log('arrrayy', this.arryData);
    }
    else {
      console.log("erorr")
    }

  }, (err) => {
    console.log(err);
  });
}


     getuserVal(name,isChecked: boolean){
       // this.link_status='Y';
       this.link_status_val=true;
 
     this.rForm.get('news_url').setValue(name);
      
    }
    
    urlInputChange(){
      this.link_status_val=false;
    }

    openlinkModal()
     {
     jQuery('#addfirst').modal({backdrop: 'static', keyboard: false});
      jQuery("#addfirst").modal("show");
      // this.getlibrary();
    }

checking(index, url) {
  this.browse = false;
  this.image = true;
  this.img = true;
  this.img_valid = true;
  $('.gallery_images li').eq(index).addClass('selected').siblings().removeClass('selected');
  console.log('url', url);
  this.imageUrl = url;
}




/**********************************get image***************************************/
  
  onFileChange(event){
    console.log(event)
 if (event.target.files[0].type === 'image/png' || event.target.files[0].type === 'image/jpeg') {
  if(event.target.files.length > 0)
    {
    this.image = false;
    this.img = true;
     this.img_valid=true;
      let file = event.target.files[0];
      console.log(file)
      this.imageUrl = file;
      // this.myForm.get('group_image').setValue(file);
      var reader = new FileReader();
      reader.onload = this._handleReaderLoaded.bind(this);
      reader.readAsDataURL(file);
    }
  }
    else {
    this.img_valid = true;
    this.img = false;
     }
   //this.saveFiles(files);
}

handleImageLoad() {
  this.imageLoaded = true;
}

_handleReaderLoaded(e) {
  this.browse = true
  console.log('image', e);
  var reader = e.target;
  this.imageSrc = reader.result;
  this.loaded = true;
}




    /**********************************Remove Groups***************************************/
   
    RemoveComm(id) {
      // alert("hiiii")
      let params={
        'type':'NE',
        'type_id':this._id
      }
    this.authService.removeNewsStore(params).then((result) => {
    console.log(result);
    this.res=result;
    if(this.res.status==true){
      jQuery("#request").modal("hide");
      this.mytable.destroy();
            setTimeout(() => {
   this.mytable=$('#example').DataTable({
    "bPaginate": true,
    "bLengthChange": true,
    // "pageLength": 7,
    "bFilter": true,
    "bInfo": false,
    "bAutoWidth": true,
    //"ordering": false
    })
   
    },500);
      this.News();
         // this.data=this.res.data;
         console.log(this.data);
    }
    else{
        console.log("erorr")
    }
     
    }, (err) => {
      console.log(err);
    });
  }


       /**********************************Get All Links***************************************/


    GetAllLinks() 
    {
    this.authService.getLinks().then((result) => {
      console.log(result);
      this.res = result;
      if (this.res.status == true) 
      {
         this.links = this.res.data;
        // console.log('arrrayy', this.arryData);
      }
      else 
      {
        console.log("erorr")
      }

    }, (err) => {
      console.log(err);
    });
  }


    /**********************************EDIT News***************************************/
   
    EditNews(val,value) {
      // alert("hiiii")
      console.log(this.id,value.news_url)
      if(val){

        let params={
        id:this.id,
        url:value.news_url,
        name:value.name
      };
    this.authService.editNews(params).then((result) => {
    console.log(result);
    this.res=result;
    if(this.res.status==true){
      this.presentToast('News Updated Successfully')
    //  alert("News Updated Successfully")
      // alert(this.res.message)
      this.clearr1();
       jQuery("#edit").modal("hide");
         this.mytable.destroy();
            setTimeout(() => {
   this.mytable=$('#example').DataTable({
    "bPaginate": true,
    "bLengthChange": true,
    // "pageLength": 7,
    "bFilter": true,
    "bInfo": false,
    "bAutoWidth": true,
    //"ordering": false
    })
   
    },500);
      // this.add_new=false;
      this.News();
    }
    else{
        console.log("erorr")
    }
     
    }, (err) => {
      console.log(err);
    });
  }
      else{
        alert("Fill Required Fields")
      }
    

      
  
  }
    /**********************************ADD News***************************************/
   
    AddNews(val,value) {
      // alert("hiiii")
      console.log(val,value)
      if(val){
    if(!this.img){
        this.img_valid=true;
       }

       else if (!this.imageUrl) {
        this.img_valid = false;
      }
      else{
         if(this.link_status_val){
       this.link_status='Y';
        }
        else{
          this.link_status='N';
        }
       let data = new FormData();
       data.append('news_url', this.rForm.get('news_url').value);
       data.append('news_image', this.imageUrl);
       data.append('name', this.rForm.get('name').value);
       data.append('link_url',  this.link_status);
       data.append('description', this.rForm.get('description').value);
    this.authService.addNews(data).then((result) => {
    console.log(result);
     this.link_status_val=false;
    this.res=result;
    if(this.res.status==true){
      this.presentToast('News Created Successfully')
     // alert("News Created Successfully")
         this.mytable.destroy();
            setTimeout(() => {
   this.mytable=$('#example').DataTable({
    "bPaginate": true,
    "bLengthChange": true,
    // "pageLength": 7,
    "bFilter": true,
    "bInfo": false,
    "bAutoWidth": true,
    //"ordering": false
    })
   
    },500);
      this.clearr();
      this.add_new=false;
      this.News();
    }
    else{
        console.log("erorr")
    }
     
    }, (err) => {
      console.log(err);
    });
  }

      }
      else{
        alert("Fill Required Fields!!!")
      }
  
  }

  /**********************************Get News***************************************/
   
    News() {
      // alert("hiiii")
    this.authService.getNews().then((result) => {
    console.log(result);
    this.res=result;
    if(this.res.status==true){
         this.data=this.res.data;
         console.log("get newssss",this.data);
    }
    else{
        console.log("erorr")
    }
     
    }, (err) => {
      console.log(err);
    });
  }

 /************************************Toast***************************/


   presentToast(msg) {

    this.toastr.success(this.res.message, '', {
  timeOut: 3000,
  tapToDismiss:true
});
  }

}
