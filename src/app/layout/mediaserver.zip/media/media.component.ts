import { Component, OnInit,ViewChild } from '@angular/core';
import { AuthServiceService } from '../../auth-service.service';
import { FormBuilder, FormControl,FormGroup,FormArray, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import * as $ from 'jquery';

declare var jQuery:any;

@Component({
  selector: 'app-media',
  templateUrl: './media.component.html',
  styleUrls: ['./media.component.scss']
})
export class MediaComponent implements OnInit {
res:any;
data:any;
id:any;
myForm: FormGroup;
file:any;
img_valid: boolean = true;
add_new: boolean = false;
@ViewChild('fileupload')
myInputVariable: any;

  constructor(
  	 private fb: FormBuilder,
    public authService: AuthServiceService,
     private toastr: ToastrService) 
  { 
  	this.myForm = this.fb.group({
         gallary_title: ['', Validators.required]
      });
  }
   ngAfterContentChecked(){
    $("#name").on("keypress", function (e) {
      if (e.which === 32 && !this.value.length)
      e.preventDefault();
      });
 }

  ngOnInit() {
  	this.GetGalleries();
  }

  showAdd(){
    this.add_new=true;
  }
  	clearForm() {

		this.myForm.reset({
		      'gallary_title': ''
		     });
		}

     RemoveClick(id){
      // alert(id)
      jQuery("#request").modal("show");
      this.id=id;


    }
  /**********************************Remove Groups***************************************/
   
    RemoveComm() {
      // alert("hiiii")
      let params={
        'type':'GA',
        'type_id':this.id
      }
    this.authService.removeMedia(params).then((result) => {
    console.log(result);
     
    this.res=result;
    if(this.res.status==true){
   jQuery("#request").modal("hide");
      // this.users();
      this.GetGalleries();
      alert("Media Gallery deleted Successfully")
         // this.data=this.res.data;
         console.log(this.data);
    }
    else{
        console.log("erorr")
    }
     
    }, (err) => {
      console.log(err);
    });
  }



/**********************************ADD GAllery***************************************/

  AddGallery(val){
  	console.log(val) 
  	if(val){
       	let params={
       		'title':this.myForm.get('gallary_title').value
       	}
       
        this.authService.addGallery(params).then((result) => {
        console.log(result);
        this.res=result;
        if(this.res.status==true){
        	this.GetGalleries();
          this.add_new=false;
          // // console.log(this.myForm.value);
          this.clearForm();
          // this.reset();
          this.presentToast('Media Gallery Created Successfully') 
          //alert("Media Gallery Created Successfully")
        }
        else{
           console.log("erorrr");
        }
           
          }, (err) => {
            console.log(err);
          });
       }
       else{
        alert("Fill Required Fields")
       }

  }

    /**********************************Get Music Albums***************************************/

  GetGalleries() {
      // alert("hiiii")
    this.authService.getGalleries().then((result) => {
    console.log(result);
    this.res=result;
    if(this.res.status==true){
         this.data=this.res.data;
         console.log(this.data);
    }
    else{
        console.log("erorr")
    }
     
    }, (err) => {
      console.log(err);
    });
  }


/************************************Toast***************************/


   presentToast(msg) {

    this.toastr.success(this.res.message, '', {
  timeOut: 3000,
  tapToDismiss:true
});
  }

}
